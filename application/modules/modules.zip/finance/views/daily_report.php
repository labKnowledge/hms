
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
    <section class="wrapper site-min-height">
        <!-- page start-->
        <section class="panel">
            <header class="panel-heading">
                <?php echo "Daily Report" ?>
            </header>
            <div class="space15"></div> 
            <div class="col-md-12">
                <div class="col-md-7">
                    <section class="panel-body">
                        <form role="form" action="finance/dailyReport" class="clearfix" method="post" enctype="multipart/form-data">
                            <div class="form-group">

                                <!--     <label class="control-label col-md-3">Date Range</label> -->
                                <div class="col-md-6">
                                    <div class="input-group input-large" data-date="13/07/2013" data-date-format="mm/dd/yyyy">
                                        <input type="text" class="form-control dpd1" name="date_from" value="<?php
                                        if (!empty($from)) {
                                            echo $from;
                                        }
                                        ?>" placeholder="<?php echo lang('date_from'); ?>">
                                        <span class="input-group-addon">To</span>
                                        <input type="text" class="form-control dpd2" name="date_to" value="<?php
                                        if (!empty($to)) {
                                            echo $to;
                                        }
                                        ?>" placeholder="<?php echo lang('date_to'); ?>">
                                    </div>
                                    <div class="row"></div>
                                    <span class="help-block"></span> 
                                </div>
                                <div class="col-md-6">
                                    <button type="submit" name="submit" class="btn btn-info range_submit"><?php echo lang('submit'); ?></button>
                                </div>
                            </div>
                        </form>
                    </section>
                </div>
                <div class="col-md-5">
                </div>
            </div>
            <div class="panel-body">
                <div class="adv-table editable-table ">
                <div class="clearfix">
                        <button class="export" onclick="javascript:window.print();"><?php echo lang('print'); ?></button>     
                    </div>
                    <div class="space15">
                        <?php
                        if (!empty($from) && !empty($to)) {
                            echo "From $from To $to";
                        }
                        ?> 
                    </div>
                    <div class="space15"></div>
                    <table class="table table-striped table-hover table-bordered table-responsive" id="comission-editable-sample">
                        <thead>
                            <tr>
                                <th><?php echo lang('invoice_id'); ?></th>
                                <th><?php echo lang('patient'); ?></th>
                                <th><?php echo "MEMBER NO"; ?></th>
                                <th><?php echo "H/NO."; ?></th>
                                <th><?php echo lang('doctor'); ?></th>
                                <th><?php echo "GP/SP"; ?></th>
                                <th><?php echo "SCHEME"; ?></th>
                                <th><?php echo "CONS"; ?></th>
                                <th><?php echo "LAB"; ?></th>
                                <th><?php echo "RAD"; ?></th>
                                <th><?php echo "PROCD"; ?></th>
                                <th><?php echo "SUND"; ?></th>
                                <th><?php echo "TOTAL" ?></t>
                                <th><?php echo "SHORTFALL" ?></t>
                                <th><?php echo "T. PHR" ?></t>
                                <th><?php echo "SHRT-PHR" ?></t>
                                <th><?php echo "IN-PATIENT" ?></t>
                                <th><?php echo "T. CREDIT" ?></th>
                                <th><?php echo "T. CASH" ?></th>
                            </tr>
                        </thead>
                        <tbody>

                        <style>

                            .img_url{
                                height:20px;
                                width:20px;
                                background-size: contain; 
                                max-height:20px;
                                border-radius: 100px;
                            }
                            .option_th{
                                width:18%;
                            }

                        </style>
                        <?php foreach ($payments as $payment) { 
                            $LAB = "";
                            $RADIOLOGY = "";
                            $SUNDRIES = "";
                            $PROCEDURE = "";
                            $SP = "";
                            $pharmacy = "";
                            $CONS = "";
                            $CREDIT = "";
                            $CASH = "";
                            $category_name = $payment->category_name;
                            $category_name1 = explode(',', $category_name);
                            $i = 0;
                            foreach ($category_name1 as $category_name2) {
                                $i = $i + 1;
                                $category_name3 = explode('*', $category_name2);
                                if ($category_name3[3] > 0) {
                                   

                                    
                                     $i; 
                                     $payment_details = $this->finance_model->getPaymentcategoryById($category_name3[0]);
                                     if (!empty($payment_details)) {
                                        $payment_type = $payment_details->description;
                                        if($payment_type=='RADIOLOGY'){
                                            $RADIOLOGY = $RADIOLOGY + $category_name3[1] * $category_name3[3];
                                        }
                                        if($payment_type=='LAB'){
                                            $LAB = $LAB + $category_name3[1] * $category_name3[3];
                                        }
                                        if($payment_type=='SUNDRIES'){
                                            $SUNDRIES = $SUNDRIES + $category_name3[1] * $category_name3[3];
                                        }
                                        if($payment_type=='PROCEDURE'){
                                            $PROCEDURE = $PROCEDURE + $category_name3[1] * $category_name3[3];
                                        }
                                        if($payment_type=='SP' or $payment_type=='GP'){
                                            $SP = $SP + $category_name3[1] * $category_name3[3];
                                        }
                                        if($payment_type=='pharmacy'){
                                            $SP = $SP + $category_name3[1] * $category_name3[3];
                                        }
                                    }
                                     $category_name3[1];
                                     $category_name3[3];
                                     $category_name3[1] * $category_name3[3];
                                    
                                
                                }
                            }
                            if($payment->deposit_type=='Cash' || $payment->deposit_type=='CASH'){
                                $CASH = $payment->amount_received;
                            }
                            else{
                                $CREDIT = $payment->amount_received;
                            }

                            $doctor_details = $this->doctor_model->getDoctorById($payment->doctor);

                            if (!empty($doctor_details)) {
                                $doctor = $doctor_details->name;
                            } else {
                                if (!empty($payment->doctor_name)) {
                                    $doctor = $payment->doctor_name;
                                } else {
                                    $doctor = $payment->doctor_name;
                                }
                            }
                            $date = date('d-m-y', $payment->date);
                            $patient_info = $this->db->get_where('patient', array('id' => $payment->patient))->row();
                            if (!empty($patient_info)) {
                                $patient_details = $patient_info->name . '</br>' . $patient_info->address . '</br>' . $patient_info->phone . '</br>';
                            } else {
                                $patient_details = ' ';
                            }
                
                            ?>

                                <tr class="">
                                    <td><?php echo $payment->id; ?></td>
                                    <td><?php echo $patient_details; ?></td>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo $doctor; ?></td>
                                    <td><?php echo $SP;?></td>
                                    <td></td>
                                    <td><?php echo $SP;?></td>
                                    <td><?php echo $LAB;?></td>
                                    <td><?php echo $RADIOLOGY;?></td>
                                    <td><?php echo $PROCEDURE;?></td>
                                    <td><?php echo $SUNDRIES;?></td>
                                    <td><?php echo $settings->currency . '' . $payment->amount; ?></td>
                                    <td><?php echo $settings->currency . '' . ($payment->gross_total - $this->finance_model->getDepositAmountByPaymentId($payment->id))?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo $CREDIT ?></td>
                                    <td><?php echo $CASH ?></td>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
        <!-- page end-->
    </section>
</section>
<!--main content end-->
<!--footer start-->
